from fastapi import FastAPI, UploadFile, File, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from langchain_community.document_loaders import PyPDFLoader, UnstructuredPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
import ollama
from pydantic import BaseModel
import os
import tempfile
import random
import json
import re
from typing import Optional, List, Dict, Any

app = FastAPI(title="Medical Report Analyzer", 
              description="API for analyzing blood tests and colonoscopy reports")

app.add_middleware(
    CORSMiddleware, 
    allow_origins=["*"], 
    allow_methods=["*"], 
    allow_headers=["*"]
)

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=2000,
    chunk_overlap=300,
    separators=["\n\n", "\n", ". ", " ", ""]
)

class DocumentStore:
    def __init__(self):
        self.documents = {}
        
    def add_document(self, doc_id: str, data: Dict[str, Any]):
        self.documents[doc_id] = data
        
    def get_document(self, doc_id: str) -> Optional[Dict[str, Any]]:
        return self.documents.get(doc_id)
        
    def get_all_document_ids(self) -> List[str]:
        return list(self.documents.keys())

document_store = DocumentStore()

class ChatRequest(BaseModel):
    user_input: str
    document_id: Optional[str] = None

class DocumentType(BaseModel):
    type: str

@app.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    doc_type: str = Query(..., description="Document type: blood_test or colonoscopy")
):
    if doc_type not in ["blood_test", "colonoscopy"]:
        raise HTTPException(400, "Invalid document type. Must be 'blood_test' or 'colonoscopy'")
    
    try:
        doc_id = f"{doc_type}_{file.filename.replace(' ', '_')}_{os.urandom(4).hex()}"
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp_file:
            content = await file.read()
            temp_file.write(content)
            temp_path = temp_file.name

        try:
            loader = PyPDFLoader(temp_path)
            documents = loader.load()
        except Exception:
            loader = UnstructuredPDFLoader(temp_path, strategy="ocr_only")
            documents = loader.load()
        
        full_text = "\n".join([doc.page_content for doc in documents])
        processed_text = advanced_medical_text_processing(full_text)
        
        if doc_type == "blood_test":
            analysis = await analyze_blood_test(processed_text)
            detailed_markers = extract_blood_markers_advanced(processed_text)
            recommendations = await get_specific_health_recommendations("blood_test", analysis, detailed_markers)
        else:
            analysis = await analyze_colonoscopy(processed_text)
            colonoscopy_findings = extract_colonoscopy_findings(processed_text)
            recommendations = await get_specific_health_recommendations("colonoscopy", analysis, colonoscopy_findings)
        
        document_store.add_document(doc_id, {
            "filename": file.filename,
            "type": doc_type,
            "text": processed_text,
            "pages": len(documents),
            "analysis": analysis,
            "extracted_data": detailed_markers if doc_type == "blood_test" else colonoscopy_findings,
            "recommendations": recommendations
        })
        
        return {
            "document_id": doc_id,
            "filename": file.filename,
            "type": doc_type,
            "pages": len(documents),
            "message": f"{doc_type.replace('_', ' ').title()} successfully analyzed"
        }
        
    except Exception as e:
        raise HTTPException(500, f"Upload processing failed: {str(e)}")
    finally:
        if 'temp_path' in locals() and os.path.exists(temp_path):
            os.unlink(temp_path)

def advanced_medical_text_processing(text: str) -> str:
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'mg\s*/\s*d[lL]', 'mg/dL', text, flags=re.IGNORECASE)
    text = re.sub(r'g\s*/\s*[lL]', 'g/L', text, flags=re.IGNORECASE)
    text = re.sub(r'ng\s*/\s*m[lL]', 'ng/mL', text, flags=re.IGNORECASE)
    text = re.sub(r'pg\s*/\s*m[lL]', 'pg/mL', text, flags=re.IGNORECASE)
    text = re.sub(r'mmol\s*/\s*[lL]', 'mmol/L', text, flags=re.IGNORECASE)
    text = re.sub(r'μ\s*mol\s*/\s*[lL]', 'μmol/L', text, flags=re.IGNORECASE)
    text = re.sub(r'pmol\s*/\s*[lL]', 'pmol/L', text, flags=re.IGNORECASE)
    text = re.sub(r'U\s*/\s*[lL]', 'U/L', text, flags=re.IGNORECASE)
    text = re.sub(r'mU\s*/\s*[lL]', 'mU/L', text, flags=re.IGNORECASE)
    text = re.sub(r'IU\s*/\s*[lL]', 'IU/L', text, flags=re.IGNORECASE)
    text = re.sub(r'0\s+\.\s+', '0.', text) 
    text = re.sub(r'(?<=[0-9])\s+(?=[0-9])', '', text)
    text = re.sub(r'[oO](?=[0-9])', '0', text)
    text = re.sub(r'(?<=[0-9])[lI]', '1', text)
    text = re.sub(r'(range|ref|reference|normal)[:\s]+([0-9.]+)[^0-9.]*([0-9.]+)', r'range: \2-\3', text, flags=re.IGNORECASE)
    text = re.sub(r'([A-Za-z]+)([0-9])', r'\1 \2', text) 
    text = re.sub(r'(?i)complete blood count|cbc', 'COMPLETE BLOOD COUNT (CBC)', text)
    text = re.sub(r'(?i)comprehensive metabolic panel|cmp', 'COMPREHENSIVE METABOLIC PANEL (CMP)', text)
    text = re.sub(r'(?i)lipid panel', 'LIPID PANEL', text)
    text = re.sub(r'(?i)thyroid panel|thyroid function', 'THYROID FUNCTION', text)
    
    return text

async def analyze_blood_test(text: str) -> str:
    try:
        markers = extract_blood_markers_advanced(text)
        markers_text = "\n".join([f"{k}: {v}" for k, v in markers.items()]) if markers else "No specific markers extracted"
        
        system_prompt = """You are an expert medical analyst. Provide a thorough analysis and diagnosis of this blood test with:

        1. Findings
        2. Systemic Analysis
        3. Clinical Significance and Diagnosis
        4. Recommendations
        5. Nutritional Interpretation"""
        
        response = ollama.chat(
            model="mistral",
            messages=[{
                "role": "system",
                "content": system_prompt
            }, {
                "role": "user",
                "content": f"Extracted markers with values:\n{markers_text}\n\nComplete report text:\n{text[:5000]}"
            }]
        )
        return response["message"]["content"]
    except Exception as e:
        print(f"Blood test analysis error: {str(e)}")
        return "Blood test analysis could not be completed due to a technical error."

async def analyze_colonoscopy(text: str) -> str:
    try:
        findings = extract_colonoscopy_findings(text)
        findings_text = json.dumps(findings, indent=2) if findings else "No structured findings extracted"
        
        system_prompt = """You are an expert medical analyst. Provide a thorough analysis and diagnosis of this colonoscopy report with:
        
        1. Procedure Details
        2. Findings
        3. Polyp Analysis
        4. Mucosal Assessment
        5. Diagnostic Impression and Diagnosis
        6. Follow-up Recommendations"""
        
        response = ollama.chat(
            model="mistral",
            messages=[{
                "role": "system",
                "content": system_prompt
            }, {
                "role": "user",
                "content": f"Extracted findings:\n{findings_text}\n\nComplete report text:\n{text[:5000]}"
            }]
        )
        return response["message"]["content"]
    except Exception as e:
        print(f"Colonoscopy analysis error: {str(e)}")
        return "Colonoscopy analysis could not be completed due to a technical error."
    
def extract_colonoscopy_findings(text: str) -> Dict[str, Any]:
    findings = {
        "procedure_details": {},
        "anatomical_findings": {},
        "polyps": [],
        "biopsies": [],
        "impression": "",
        "recommendations": ""
    }
    
    scope_match = re.search(r'(?:scope|instrument)(?:[:\s]+)([^\.]+)', text, re.IGNORECASE)
    if scope_match:
        findings["procedure_details"]["scope_type"] = scope_match.group(1).strip()
    
    prep_match = re.search(r'(?:bowel\s+prep|preparation)(?:[:\s]+)([^\.]+)(?:quality|assessment)?(?:[:\s]+)?([^\.]+)?', text, re.IGNORECASE)
    if prep_match:
        prep_desc = prep_match.group(1).strip()
        if prep_match.group(2):
            prep_desc += " " + prep_match.group(2).strip()
        findings["procedure_details"]["preparation"] = prep_desc
    
    extent_match = re.search(r'(?:extent|reached|advanced|insertion|examined\s+to)(?:[:\s]+)([^\.]+)', text, re.IGNORECASE)
    if extent_match:
        findings["procedure_details"]["extent"] = extent_match.group(1).strip()
    
    anatomy_patterns = [
        (r'(?:rectum|rectal)(?:[:\s]+)([^\.]+)', "Rectum"),
        (r'(?:sigmoid|sigmoid\s+colon)(?:[:\s]+)([^\.]+)', "Sigmoid"),
        (r'(?:descending\s+colon)(?:[:\s]+)([^\.]+)', "Descending Colon"),
        (r'(?:splenic\s+flexure|left\s+flexure)(?:[:\s]+)([^\.]+)', "Splenic Flexure"),
        (r'(?:transverse\s+colon)(?:[:\s]+)([^\.]+)', "Transverse Colon"),
        (r'(?:hepatic\s+flexure|right\s+flexure)(?:[:\s]+)([^\.]+)', "Hepatic Flexure"),
        (r'(?:ascending\s+colon)(?:[:\s]+)([^\.]+)', "Ascending Colon"),
        (r'(?:cecum|cecal)(?:[:\s]+)([^\.]+)', "Cecum"),
        (r'(?:ileocecal\s+valve|IC\s+valve)(?:[:\s]+)([^\.]+)', "Ileocecal Valve"),
        (r'(?:terminal\s+ileum|TI)(?:[:\s]+)([^\.]+)', "Terminal Ileum")
    ]
    
    for pattern, location in anatomy_patterns:
        matches = re.search(pattern, text, re.IGNORECASE)
        if matches:
            findings["anatomical_findings"][location] = matches.group(1).strip()
    
    polyp_pattern = r'(?:polyp|lesion)(?:[:\s]+)([^\.]+)'
    polyp_matches = re.finditer(polyp_pattern, text, re.IGNORECASE)
    
    for match in polyp_matches:
        polyp_desc = match.group(1).strip()
        polyp_info = {"description": polyp_desc}
        
        size_match = re.search(r'(\d+)\s*(?:mm|cm)', polyp_desc, re.IGNORECASE)
        if size_match:
            polyp_info["size"] = size_match.group(0).strip()
        
        for location in ["rectum", "sigmoid", "descending", "transverse", "ascending", "cecum"]:
            if re.search(location, polyp_desc, re.IGNORECASE):
                polyp_info["location"] = location.title()
                break
        
        for morphology in ["sessile", "pedunculated", "flat", "depressed", "paris"]:
            if re.search(morphology, polyp_desc, re.IGNORECASE):
                polyp_info["morphology"] = morphology.title()
                break
        
        for method in ["snare", "biopsy", "hot", "cold", "EMR", "ESD"]:
            if re.search(method, polyp_desc, re.IGNORECASE):
                polyp_info["removal_method"] = method.upper() if method in ["EMR", "ESD"] else method.title()
                break
        
        findings["polyps"].append(polyp_info)
    
    biopsy_pattern = r'(?:biopsy|biopsies)(?:[:\s]+)([^\.]+)'
    biopsy_matches = re.finditer(biopsy_pattern, text, re.IGNORECASE)
    
    for match in biopsy_matches:
        biopsy_desc = match.group(1).strip()
        biopsy_info = {"description": biopsy_desc}
        
        for location in ["rectum", "sigmoid", "descending", "transverse", "ascending", "cecum", "ileum"]:
            if re.search(location, biopsy_desc, re.IGNORECASE):
                biopsy_info["location"] = location.title()
                break
        
        for reason in ["inflammation", "erythema", "ulcer", "erosion", "nodule", "mass"]:
            if re.search(reason, biopsy_desc, re.IGNORECASE):
                biopsy_info["indication"] = reason.title()
                break
        
        findings["biopsies"].append(biopsy_info)
    
    impression_match = re.search(r'(?:impression|diagnosis|assessment)(?:[:\s]+)([^\.]+(?:\.[^\.]+){0,3})', text, re.IGNORECASE)
    if impression_match:
        findings["impression"] = impression_match.group(1).strip()
    
    recommendation_match = re.search(r'(?:recommendation|plan|follow[\s-]*up)(?:[:\s]+)([^\.]+(?:\.[^\.]+){0,3})', text, re.IGNORECASE)
    if recommendation_match:
        findings["recommendations"] = recommendation_match.group(1).strip()
    
    return findings

async def get_specific_health_recommendations(doc_type: str, analysis: str, findings: Dict) -> str:
    try:
        findings_text = json.dumps(findings, indent=2)
        
        system_prompt = f"""You are an expert medical advisor. Provide specific, actionable recommendations for:
        
        1. Dietary Modifications
        2. Lifestyle Interventions
        3. Supplement Considerations
        4. Monitoring Strategy
        5. Education"""
        
        response = ollama.chat(
            model="mistral",
            messages=[{
                "role": "system",
                "content": system_prompt
            }, {
                "role": "user",
                "content": f"Document type: {doc_type}\n\nAnalysis:\n{analysis}\n\nDetailed findings:\n{findings_text}"
            }]
        )
        return response["message"]["content"]
    except Exception as e:
        print(f"Recommendations generation error: {str(e)}")
        return "Health recommendations could not be generated due to a technical error."

@app.get("/document/{doc_id}")
async def get_document(doc_id: str):
    doc = document_store.get_document(doc_id)
    if not doc:
        raise HTTPException(404, "Document not found")
    
    return doc

@app.get("/documents")
async def list_documents():
    doc_ids = document_store.get_all_document_ids()
    documents = []
    
    for doc_id in doc_ids:
        doc = document_store.get_document(doc_id)
        if doc:
            documents.append({
                "document_id": doc_id,
                "filename": doc.get("filename", "Unknown"),
                "type": doc.get("type", "Unknown"),
                "pages": doc.get("pages", 0)
            })
    
    return {"documents": documents}

def extract_blood_markers_advanced(text: str) -> Dict[str, Dict[str, str]]:
    markers = {}
    patterns = [
        (r'(?:hemoglobin|hgb|hb)[:\s]+([0-9.]+)\s*(?:g/dl|g/l)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'Hemoglobin'),
        (r'(?:hematocrit|hct)[:\s]+([0-9.]+)\s*%[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'Hematocrit'),
        (r'(?:wbc|white\s+blood\s+cells|leukocytes)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'WBC'),
        (r'(?:rbc|red\s+blood\s+cells|erythrocytes)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'RBC'),
        (r'(?:platelets|plt|thrombocytes)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'Platelets'),
        (r'(?:mcv|mean\s+corpuscular\s+volume)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'MCV'),
        (r'(?:mch|mean\s+corpuscular\s+hemoglobin)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'MCH'),
        (r'(?:mchc|mean\s+corpuscular\s+hemoglobin\s+concentration)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'MCHC'),
        (r'(?:neutrophils|neut)[:\s]+([0-9.]+)(?:\s*%|\s*x10\^9/L)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'Neutrophils'),
        (r'(?:lymphocytes|lymph)[:\s]+([0-9.]+)(?:\s*%|\s*x10\^9/L)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'Lymphocytes'),
        (r'(?:monocytes|mono)[:\s]+([0-9.]+)(?:\s*%|\s*x10\^9/L)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'Monocytes'),
        (r'(?:eosinophils|eos)[:\s]+([0-9.]+)(?:\s*%|\s*x10\^9/L)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'Eosinophils'),
        (r'(?:basophils|baso)[:\s]+([0-9.]+)(?:\s*%|\s*x10\^9/L)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'CBC', 'Basophils'),
        
        # Liver Function
        (r'(?:alt|alanine\s+(?:amino)?transaminase|sgpt)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Liver', 'ALT'),
        (r'(?:ast|aspartate\s+(?:amino)?transaminase|sgot)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Liver', 'AST'),
        (r'(?:alp|alkaline\s+phosphatase)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Liver', 'ALP'),
        (r'(?:ggt|gamma(?:\s*-?glutamyl)?\s*transferase)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Liver', 'GGT'),
        (r'(?:total\s+bilirubin|tbil)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Liver', 'Total Bilirubin'),
        (r'(?:direct\s+bilirubin|dbil|conjugated\s+bilirubin)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Liver', 'Direct Bilirubin'),
        (r'(?:albumin|alb)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Liver', 'Albumin'),
        (r'(?:total\s+protein|tp)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Liver', 'Total Protein'),
        
        # Kidney Function
        (r'(?:creatinine|cre|cr)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Kidney', 'Creatinine'),
        (r'(?:bun|blood\s+urea\s+nitrogen|urea)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Kidney', 'BUN'),
        (r'(?:egfr|estimated\s+glomerular\s+filtration\s+rate)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Kidney', 'eGFR'),
        (r'(?:uric\s+acid)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Kidney', 'Uric Acid'),
        
        # Lipids
        (r'(?:total\s+cholesterol|tc|cholesterol)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal|desirable)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Lipids', 'Total Cholesterol'),
        (r'(?:hdl|hdl-c|high[\s-]density\s+lipoprotein)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal|desirable)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Lipids', 'HDL'),
        (r'(?:ldl|ldl-c|low[\s-]density\s+lipoprotein)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal|desirable)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Lipids', 'LDL'),
        (r'(?:triglycerides|tg)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal|desirable)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Lipids', 'Triglycerides'),
        (r'(?:non-hdl\s+cholesterol)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal|desirable)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Lipids', 'Non-HDL Cholesterol'),
        (r'(?:tc/hdl\s+ratio|cholesterol/hdl\s+ratio)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal|desirable)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Lipids', 'TC/HDL Ratio'),
        
        # Glucose Metabolism
        (r'(?:glucose|glu|fbs|fbg|fasting\s+(?:blood\s+)?glucose)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Glucose', 'Glucose'),
        (r'(?:a1c|hba1c|glycated\s+hemoglobin|hemoglobin\s+a1c)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Glucose', 'HbA1c'),
        (r'(?:insulin)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Glucose', 'Insulin'),
        (r'(?:homa-ir)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Glucose', 'HOMA-IR'),
        
        # Electrolytes
        (r'(?:sodium|na)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Electrolytes', 'Sodium'),
        (r'(?:potassium|k)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Electrolytes', 'Potassium'),
        (r'(?:chloride|cl)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Electrolytes', 'Chloride'),
        (r'(?:bicarbonate|co2|carbon\s+dioxide)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Electrolytes', 'Bicarbonate'),
        (r'(?:calcium|ca)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Electrolytes', 'Calcium'),
        (r'(?:magnesium|mg)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Electrolytes', 'Magnesium'),
        (r'(?:phosphorus|phosphate)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Electrolytes', 'Phosphorus'),
        
        # Thyroid Function
        (r'(?:tsh|thyroid\s+stimulating\s+hormone)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Thyroid', 'TSH'),
        (r'(?:free\s+t4|ft4)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Thyroid', 'Free T4'),
        (r'(?:free\s+t3|ft3)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Thyroid', 'Free T3'),
        (r'(?:total\s+t4)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Thyroid', 'Total T4'),
        (r'(?:total\s+t3)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Thyroid', 'Total T3'),
        
        # Iron Status
        (r'(?:iron|fe)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Iron', 'Iron'),
        (r'(?:ferritin)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Iron', 'Ferritin'),
        (r'(?:tibc|total\s+iron\s+binding\s+capacity)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Iron', 'TIBC'),
        (r'(?:transferrin\s+saturation|tsat)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Iron', 'Transferrin Saturation'),
        
        # Inflammation Markers
        (r'(?:crp|c-reactive\s+protein)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Inflammation', 'CRP'),
        (r'(?:esr|sed\s+rate|erythrocyte\s+sedimentation\s+rate)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Inflammation', 'ESR'),
        
        # Vitamins & Minerals
        (r'(?:vitamin\s+b12|b12)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Vitamins', 'Vitamin B12'),
        (r'(?:folate|folic\s+acid)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Vitamins', 'Folate'),
        (r'(?:vitamin\s+d|25-oh\s+vitamin\s+d)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Vitamins', 'Vitamin D'),
        (r'(?:zinc|zn)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Minerals', 'Zinc'),
        
        # Hormones
        (r'(?:testosterone|total\s+testosterone)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Hormones', 'Testosterone'),
        (r'(?:estradiol|e2)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Hormones', 'Estradiol'),
        (r'(?:progesterone)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Hormones', 'Progesterone'),
        # Hormones
        (r'(?:cortisol)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Hormones', 'Cortisol'),
        (r'(?:prolactin)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Hormones', 'Prolactin'),
        (r'(?:dhea-s|dheas)[:\s]+([0-9.]+)[^\n]*(?:range|ref|normal)[:\s]+([0-9.]+)\s*[-–to]+\s*([0-9.]+)', 
         'Hormones', 'DHEA-S')
    ]
    
    for pattern, category, name in patterns:
        matches = re.finditer(pattern, text, re.IGNORECASE)
        for match in matches:
            if len(match.groups()) >= 3:
                value = match.group(1)
                lower_ref = match.group(2)
                upper_ref = match.group(3)
                
                if category not in markers:
                    markers[category] = {}
                
                markers[category][name] = {
                    "value": value,
                    "reference_range": f"{lower_ref}-{upper_ref}"
                }
    
    return markers

@app.post("/chat")



@app.post("/chat")
async def chat_with_document(request: ChatRequest):
    try:
        if request.document_id:
            doc = document_store.get_document(request.document_id)
            if not doc:
                raise HTTPException(404, "Document not found")
            
            doc_text = doc.get("text", "")
            doc_type = doc.get("type", "unknown")
            analysis = doc.get("analysis", "")
            extracted_data = doc.get("extracted_data", {})
            
            if doc_type == "blood_test":
                context = f"Document Type: Blood Test\n\n"
                context += "ANALYSIS SUMMARY:\n" + analysis[:1000] + "\n\n"
                context += "DETAILED MARKERS:\n"
                
                for category, markers in extracted_data.items():
                    context += f"\n{category}:\n"
                    for marker_name, marker_data in markers.items():
                        context += f"- {marker_name}: {marker_data['value']} (Reference: {marker_data['reference_range']})\n"
            else:
                context = f"Document Type: Colonoscopy Report\n\n"
                context += "ANALYSIS SUMMARY:\n" + analysis[:1000] + "\n\n"
                context += "PROCEDURE DETAILS:\n"
                for key, value in extracted_data.get("procedure_details", {}).items():
                    context += f"- {key.replace('_', ' ').title()}: {value}\n"
                
                context += "\nANATOMICAL FINDINGS:\n"
                for location, finding in extracted_data.get("anatomical_findings", {}).items():
                    context += f"- {location}: {finding}\n"
                
                if extracted_data.get("polyps"):
                    context += "\nPOLYPS FOUND:\n"
                    for polyp in extracted_data.get("polyps", []):
                        context += f"- {polyp.get('description', 'Not described')}\n"
                
                context += f"\nIMPRESSION: {extracted_data.get('impression', 'Not specified')}\n"
                context += f"\nRECOMMENDATIONS: {extracted_data.get('recommendations', 'Not specified')}\n"
            
            system_prompt = """You are an expert medical assistant. Answer questions based on the provided document context. When appropriate:
            
            1. Reference specific values or findings from the document
            2. Explain medical terminology in plain language
            3. Provide context for understanding the significance of specific results
            4. Highlight important patterns or relationships between different markers
            5. Address concerns in a balanced, educational manner
            
            Be concise and factual. Provide direct answers without lengthy explanations. If a question cannot be answered based on the provided context, clearly state this limitation."""
            
            response = ollama.chat(
                model="mistral",
                messages=[{
                    "role": "system",
                    "content": system_prompt
                }, {
                    "role": "user",
                    "content": f"Document Context:\n{context}\n\nUser Question: {request.user_input}"
                }]
            )
            return {"response": response["message"]["content"]}
        else:
            system_prompt = """You are an expert medical assistant specializing in blood tests and colonoscopy reports.
            Provide educational information about medical tests, terminology, and general health concepts.
            
            When answering questions:
            1. Explain medical concepts clearly using plain language
            2. Define relevant medical terminology
            3. Provide general information about test purposes and interpretation
            4. Explain typical ranges and what abnormalities might indicate
            5. Discuss relevant health concepts in an educational manner
            
            Be concise and factual. Provide direct answers without lengthy explanations."""
            
            response = ollama.chat(
                model="mistral",
                messages=[{
                    "role": "system",
                    "content": system_prompt
                }, {
                    "role": "user",
                    "content": request.user_input
                }]
            )
            return {"response": response["message"]["content"]}
    except Exception as e:
        raise HTTPException(500, f"Chat processing failed: {str(e)}")@app.get("/random_greeting")



async def get_random_greeting():
    greetings = [
        "Hello! I can help analyze blood test or colonoscopy PDFs or answer general health questions.",
        "Welcome! I'm here to help you understand your medical reports and answer health questions.",
        "Hi there! Upload your medical reports or ask me anything about gut health.",
        "Greetings! I specialize in analyzing blood tests and colonoscopy reports."
    ]
    return {"greeting": random.choice(greetings)}

@app.get("/disease_info/{disease_name}")
async def get_disease_info(disease_name: str):
    disease_db = {
        "ibs": {
            "disease": "Irritable Bowel Syndrome (IBS)",
            "description": "A common disorder affecting the large intestine.",
            "symptoms": ["Abdominal pain", "Bloating", "Diarrhea", "Constipation"],
            "treatments": ["Diet changes", "Stress management", "Medications"],
            "additional_notes": "Symptoms often improve with lifestyle changes."
        },
        "crohn's disease": {
            "disease": "Crohn's Disease",
            "description": "A type of inflammatory bowel disease (IBD).",
            "symptoms": ["Diarrhea", "Abdominal pain", "Fatigue", "Weight loss"],
            "treatments": ["Anti-inflammatory drugs", "Immune system suppressors", "Surgery"],
            "additional_notes": "Requires long-term management."
        },
        "celiac disease": {
            "disease": "Celiac Disease",
            "description": "An immune reaction to eating gluten.",
            "symptoms": ["Diarrhea", "Bloating", "Weight loss", "Fatigue"],
            "treatments": ["Strict gluten-free diet"],
            "additional_notes": "Damage to small intestine can occur if gluten is consumed."
        }
    }
    
    disease_name_lower = disease_name.lower()
    if disease_name_lower in disease_db:
        return disease_db[disease_name_lower]
    else:
        raise HTTPException(404, "Disease information not available")

@app.get("/meal_plan/{disease_name}")
async def get_meal_plan(disease_name: str, variety: bool = False, servings: int = 1):
    meal_plans = {
        "ibs": {
            "disease": "Irritable Bowel Syndrome (IBS)",
            "description": "Low-FODMAP diet recommended",
            "meal_plans": [
                {
                    "day": 1,
                    "breakfast": ["Oatmeal with banana", "Peppermint tea"],
                    "lunch": ["Grilled chicken salad", "Quinoa"],
                    "dinner": ["Baked salmon", "Steamed carrots"],
                    "snacks": ["Rice cakes", "Lactose-free yogurt"],
                    "nutrition_notes": "Avoid high-FODMAP foods"
                }
            ],
            "additional_notes": "Keep a food diary to identify triggers"
        },
        "crohn's disease": {
            "disease": "Crohn's Disease",
            "description": "Easily digestible foods recommended",
            "meal_plans": [
                {
                    "day": 1,
                    "breakfast": ["Scrambled eggs", "White toast"],
                    "lunch": ["Baked chicken", "Mashed potatoes"],
                    "dinner": ["Baked fish", "Cooked carrots"],
                    "snacks": ["Banana", "Applesauce"],
                    "nutrition_notes": "Avoid high-fiber foods during flare-ups"
                }
            ],
            "additional_notes": "Small, frequent meals may be better tolerated"
        }
    }
    
    disease_name_lower = disease_name.lower()
    if disease_name_lower in meal_plans:
        return meal_plans[disease_name_lower]
    else:
        raise HTTPException(404, "Meal plan not available for this condition")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)