document.addEventListener("DOMContentLoaded", function () {
    const fields = [
        "username", "email", "first_name", "last_name", "date_of_birth", "gender",
        "blood_type", "known_allergies", "chronic_conditions", "current_medications",
        "height_cm", "weight_kg"
    ];

    const defaultData = {
        username: "user123",
        email: "user123@example.com",
        first_name: "John",
        last_name: "Doe",
        date_of_birth: "1990-01-01",
        gender: "Male",
        blood_type: "O+",
        known_allergies: "Peanuts",
        chronic_conditions: "Diabetes",
        current_medications: "Metformin",
        height_cm: "175",
        weight_kg: "70",
        profile_picture: "https://randomuser.me/api/portraits/men/32.jpg"
    };

    let userData = JSON.parse(localStorage.getItem("gutguard_profile")) || defaultData;

    function fillProfileFields(data) {
        fields.forEach(key => {
            const input = document.getElementById(key);
            if (input) input.value = data[key] || "";
        });

        const img = document.getElementById("profileImage");
        if (img && data.profile_picture) {
            img.src = data.profile_picture;
        }
    }

    function getProfileFields() {
        const data = {};
        fields.forEach(key => {
            const input = document.getElementById(key);
            if (input) data[key] = input.value;
        });
        data.profile_picture = document.getElementById("profileImage").src;
        return data;
    }

    function toggleEditMode() {
        const inputs = document.querySelectorAll("input:not(#imageUpload)");
        const isDisabled = inputs[0].disabled;
        inputs.forEach(input => input.disabled = !isDisabled);

        const editBtn = document.getElementById("editBtn");
        editBtn.textContent = isDisabled ? "Save" : "Edit";

        if (!isDisabled) {
            const updatedData = getProfileFields();
            localStorage.setItem("gutguard_profile", JSON.stringify(updatedData));
            alert("Profile saved successfully!");
        }
    }

    function resetProfile() {
        localStorage.removeItem("gutguard_profile");
        userData = defaultData;
        fillProfileFields(defaultData);
        document.querySelectorAll("input").forEach(input => input.disabled = true);
        document.getElementById("editBtn").textContent = "Edit";
        alert("Profile reset to default.");
    }

    function handleImageUpload(event) {
        const file = event.target.files[0];
        if (file && file.type.startsWith("image/")) {
            const reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById("profileImage").src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    }

    document.getElementById("editBtn").addEventListener("click", toggleEditMode);
    document.getElementById("resetBtn").addEventListener("click", resetProfile);
    document.getElementById("imageUpload").addEventListener("change", handleImageUpload);

    fillProfileFields(userData);
});
